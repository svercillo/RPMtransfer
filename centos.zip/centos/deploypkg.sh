yum remove -y  booster
yum install -y /home/snvercil/rpmbuild/RPMS/x86_64/booster-0.9-1.el7.x86_64.rpm
